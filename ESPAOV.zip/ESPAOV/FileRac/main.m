#import "main.h"
#import <mach/mach.h>
#include <sys/sysctl.h>
#include <sys/param.h>
#include <sys/mount.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <SafariServices/SafariServices.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "SSZipArchive/SSZipArchive.h"
//#import "iconlq/iconlq.h"
#import "FTNotificationIndicator.h"



#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width


@interface main () <UIGestureRecognizerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>


@property (nonatomic, strong) UIDocumentPickerViewController *documentPicker;

@end

@implementation main{
    UIDocumentPickerViewController *_documentPicker;
}



static main *extraInfo;

+ (instancetype)sharemain {
    static main *sharemain;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{
        sharemain = [[main alloc] init];
    });

    return sharemain;
}

+ (void)load {
   

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [main sharemain];
    });
}

- (void)suce {
   
    // Sử dụng GCD để thoát ứng dụng sau 3 giây
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        exit(0);
    });
}


- (instancetype)init {
    self = [super init];
    if (self) {
 
        }
    return self;
}
- (void)modskinquafile {
    _documentPicker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[(NSString *)kUTTypeZipArchive] inMode:UIDocumentPickerModeImport];
    _documentPicker.delegate = self;

    if (@available(iOS 11.0, *)) {
        _documentPicker.allowsMultipleSelection = NO; //chỉ đọc với ios11 trở lên
    }

    UIViewController *rootViewController = [[[UIApplication sharedApplication] keyWindow] rootViewController];
    [rootViewController presentViewController:_documentPicker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *fileURL = urls.firstObject;

    // Tạo bản sao lưu của thư mục Resources trước khi giải nén 
    [self modbackup];

    [self giainen:fileURL];
    [controller dismissViewControllerAnimated:YES completion:nil];
}

- (void)cancel:(UIDocumentPickerViewController *)controller {
    [controller dismissViewControllerAnimated:YES completion:nil];
}

- (void)giainen:(NSURL *)url {
    NSString *filePath = [url path];

    // Di chuyển file zip đến thư mục của ứng dụng
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *destinationPath = [documentsDir stringByAppendingPathComponent:[url lastPathComponent]];

    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;

    BOOL success = [fileManager moveItemAtPath:filePath toPath:destinationPath error:&error];

    if (!success) {
        NSLog(@"Lỗi khi di chuyển file zip: %@", error.localizedDescription);
        return;
    }

    // Giải nén tệp zip vào thư mục "Resources" hiện tại
    NSString *dataPathWtHaxVN = [documentsDir stringByAppendingPathComponent:@"/"]; //thực hiện ghi đè
    success = [SSZipArchive unzipFileAtPath:destinationPath toDestination:dataPathWtHaxVN];

    if (success) {
        NSLog(@"Giải nén thành công vào thư mục Resources");

        // Xóa file zip sau khi giải nén thành công
        [fileManager removeItemAtPath:destinationPath error:&error];
        if (error) {
            NSLog(@"Lỗi khi xóa file zip: %@", error.localizedDescription);
        }

        // Hiển thị thông báo thành công
        [self modsuccess];
    } else {
        NSLog(@"Lỗi khi giải nén: %@", error.localizedDescription);
    }
}

// Phương thức backupMod
- (void)modbackup { //backup lại file resource để sau khi xoá mod không phải tải lại 100mb tài nguyên
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *documentDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *dataPath = [documentDir stringByAppendingPathComponent:@"/"];
    NSString *backupPath = [documentDir stringByAppendingPathComponent:@"/Resources.backup"];
    NSString *resourcesPath = [dataPath stringByAppendingPathComponent:@"/Resources"];
    
    if ([fileManager fileExistsAtPath:resourcesPath]) {
        if (![fileManager fileExistsAtPath:backupPath]) {
            
            NSError *backupError;
            if (![fileManager copyItemAtPath:resourcesPath toPath:backupPath error:&backupError]) {
            }
        }
    } else {
     
    }
}

-(void)modsuccess { //thực hiện thông báo thành công hoặc exit với lệnh exit(0);
      UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Thông báo"
                                                                             message:@"Mod Thành Công\n thoát game vào lại để hoàn thành mod"
                                                                             
                                                                    preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:okAction];
    
    UIViewController *rootViewController = [[[UIApplication sharedApplication] keyWindow] rootViewController];
    [rootViewController presentViewController:alertController animated:YES completion:nil];

   
        

     


}
@end