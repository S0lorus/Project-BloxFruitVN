#import "ModSkin.h"
#import "mahoa.h"
//cái này được làm lại bởi quang (ăn cắp clmm)

NSString * const __kLinkModtURLFormat = @"https://quangmodgame.com/debmod.php?hash=%@";

@implementation QuangmodSkin

UIAlertController *alertCtrl;
UIAlertController *dialogCtrl;
NSFileManager *fileManager = [NSFileManager defaultManager];
NSString *documentDir = [NSSearchPathForDirectoriesInDomains(
    NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
bool check_Mod = false;
BOOL isCreatingBackup = NO;

+ (void)ActiveModSkin {
    NSString *dataPathQuang = [documentDir stringByAppendingPathComponent:@"/"];
    NSString *backupPathQuang = [documentDir stringByAppendingPathComponent:@"/Resources.backup"];

    if ([fileManager fileExistsAtPath:backupPathQuang]) {
        NSError *deleteErrorQuang;
        if ([fileManager removeItemAtPath:[dataPathQuang stringByAppendingPathComponent:@"/Resources"] error:&deleteErrorQuang]) {
            NSError *renameErrorQuang;
            if ([fileManager moveItemAtPath:backupPathQuang toPath:[dataPathQuang stringByAppendingPathComponent:@"/Resources"] error:&renameErrorQuang]) {
                [self fetchModLinkFromServer];
            } else {
                [self showInvalidBackupErrorAlert];
            }
        } else {
            [self showDeleteErrorAlert];
        }
    } else {
        [self fetchModLinkFromServer];
    }
    
   // [self fetchModLinkFromServer];
}

+ (void)fetchModLinkFromServer {
   
}

+ (void)showConfirmationAlertWithLink:(NSString *)modLink {
    UIAlertController *confirmationDialog = [UIAlertController alertControllerWithTitle:NSSENCRYPT("Xác nhận")
                                                                                 message:NSSENCRYPT("Bạn có muốn tải mod skin không?")
                                                                          preferredStyle:UIAlertControllerStyleAlert];
    [confirmationDialog addAction:[UIAlertAction actionWithTitle:NSSENCRYPT("Hủy")
                                                           style:UIAlertActionStyleCancel
                                                         handler:nil]];
    [confirmationDialog addAction:[UIAlertAction actionWithTitle:@"OK"
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction *_Nonnull action) {
        [self startModSkinProcessWithLink:modLink];
    }]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:confirmationDialog animated:YES completion:nil];
}

+ (void)startModSkinProcessWithLink:(NSString *)modLink {
    NSString *convertedLinkQuang = [modLink stringByReplacingOccurrencesOfString:@"file/d/" withString:@"uc?export=download&id="];
    convertedLinkQuang = [convertedLinkQuang stringByReplacingOccurrencesOfString:@"/view?usp=drivesdk" withString:@""];

    NSString *dataPathQuang = [documentDir stringByAppendingPathComponent:@"/"];
    NSString *backupPathQuang = [documentDir stringByAppendingPathComponent:@"/Resources.backup"];
    NSString *old_file_Quang = [documentDir stringByAppendingPathComponent:@"/Resources"];

    if ([fileManager fileExistsAtPath:old_file_Quang]) {
        if (![fileManager fileExistsAtPath:backupPathQuang]) {
            [self showCreatingBackupAlert];
            isCreatingBackup = YES;

            NSError *backupError;
            if (![fileManager copyItemAtPath:[dataPathQuang stringByAppendingPathComponent:@"/Resources"] toPath:backupPathQuang error:&backupError]) {
                [self showErrorAlert:@"Error" withMessage:@"Không thể tạo file backup do thư mục gốc không tồn tại hoặc lỗi không xác định"];
            } else {
                check_Mod = true;
                isCreatingBackup = NO;
                [alertCtrl dismissViewControllerAnimated:YES completion:nil];
            }
        } else {
            check_Mod = true;
        }
    } else {
        [self showErrorAlert:@"Error" withMessage:@"Không thể tạo file backup do thư mục gốc không tồn tại hoặc lỗi khác"];
    }
    if (check_Mod == true) {
        [self showLoadingAlert];

        NSString *downloadUrlQuang = [NSString stringWithFormat:@"%@", convertedLinkQuang];
        NSURLRequest *requestquang = [NSURLRequest requestWithURL:[NSURL URLWithString:downloadUrlQuang]];

        [NSURLConnection sendAsynchronousRequest:requestquang
                                           queue:[NSOperationQueue currentQueue]
                               completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            if (error) {
                [self showErrorAlert:@"Lỗi Máy Chủ" withMessage:@"Tải Data Thất Bại"];
            } else {
                NSString *tempZipPath = [documentDir stringByAppendingPathComponent:@"Resources.zip"];
                [data writeToFile:tempZipPath atomically:YES];
                BOOL success = [SSZipArchive unzipFileAtPath:tempZipPath toDestination:dataPathQuang];
                [fileManager removeItemAtPath:tempZipPath error:nil];
                if (success) {
                    [self showSuccessAlert:@"Mod Skin Thành Công!" withExit:YES];
                } else {
                    [self showErrorAlert:@"Error" withMessage:@"Giải nén tệp zip thất bại\nVui lòng tạo tệp zip như hướng dẫn"];
                }
            }
        }];
    }
}

+ (void)ActiveModSkin1 {
    dialogCtrl =
        [UIAlertController alertControllerWithTitle:NSSENCRYPT("Link Tải Mod Data")
                                            message:NSSENCRYPT("Vui Lòng Nhập Link Mod Skin")
                                     preferredStyle:UIAlertControllerStyleAlert];
    [dialogCtrl addTextFieldWithConfigurationHandler:^(UITextField *Text) {
      Text.placeholder = NSSENCRYPT("Dán link ...");
    }];
    [dialogCtrl addAction:[UIAlertAction actionWithTitle:NSSENCRYPT("Hủy")
                                                   style:UIAlertActionStyleCancel
                                                 handler:nil]];
    [dialogCtrl addAction:
                    [UIAlertAction
                        actionWithTitle:@"OK"
                                  style:UIAlertActionStyleDefault
                                handler:
                                    ^(UIAlertAction *_Nonnull action) {
                                      UITextField *inputFieldQuang =
                                          dialogCtrl.textFields.firstObject;
                                      NSString *inputTextQuang =
                                          inputFieldQuang.text;
                                      NSString *convertedLinkQuang = [inputTextQuang
                                          stringByReplacingOccurrencesOfString:
                                              @"file/d/"
                                                withString:
                                                    @"uc?"
                                                    @"export="
                                                    @"downloa"
                                                    @"d&id="];
                                      convertedLinkQuang = [convertedLinkQuang
                                          stringByReplacingOccurrencesOfString:
                                              @"/view?usp=drivesdk"
                                                withString:
                                                    @""];
                                      NSString *dataPathQuang = [documentDir
                                          stringByAppendingPathComponent:@"/"];
                                      NSString *backupPathQuang = [documentDir
                                          stringByAppendingPathComponent:
                                              @"/Resources.backup"];
                                      NSString *old_file_Quang = [documentDir
                                          stringByAppendingPathComponent:
                                              @"/Resources"];

                                      if ([inputTextQuang isEqualToString:@""]) {

                                        [self showErrorAlert:@"Warring" withMessage:@"Vui lòng nhập Link tải Mod Skin"];

                                      } else {
                                        if ([fileManager
                                                fileExistsAtPath:old_file_Quang]) {
                                          if (![fileManager fileExistsAtPath:
                                                                backupPathQuang]) {
                                            [self showCreatingBackupAlert]; 
                                            isCreatingBackup = YES; 

                                            NSError *backupError;
                                            if (![fileManager
                                                    copyItemAtPath:
                                                        [dataPathQuang
                                                            stringByAppendingPathComponent:
                                                                @"/Resources"]
                                                            toPath:backupPathQuang
                                                             error:&
                                                                   backupError]) {
                                              [self showErrorAlert:@"Error" withMessage:@"Không Thể Tạo File Backup Do Thư Mục Gốc Không Tồn Tại Hoặc Lỗi Không Xác Định"];
                                            } else {
                                              check_Mod = true;
                                              isCreatingBackup = NO; 
                                              [alertCtrl dismissViewControllerAnimated:YES completion:nil]; 
                                            }
                                          } else {
                                            check_Mod = true;
                                          }
                                        } else {
                                          [self showErrorAlert:@"Error" withMessage:@"Không Thể Tạo File Backup Do Thư Mục Gốc Không Tồn Tại Hoặc Lỗi Khác"];
                                        }
                                        if (check_Mod == true) {
                                          [self showLoadingAlert];

                                          NSString *downloadUrlQuang = [NSString
                                              stringWithFormat:@"%@",
                                                               convertedLinkQuang];
                                          NSURLRequest *requestquang =
                                              [NSURLRequest
                                                  requestWithURL:
                                                      [NSURL
                                                          URLWithString:
                                                              downloadUrlQuang]];

                                          [NSURLConnection sendAsynchronousRequest:
                                                               requestquang
                                                                             queue:
                                                                                 [NSOperationQueue
                                                                                     currentQueue]
                                                                 completionHandler:
                                                                     ^(
                                                                         NSURLResponse
                                                                             *response,
                                                                         NSData *
                                                                             data,
                                                                         NSError *
                                                                             error) {
                                                                       if (error) {
                                                                         [self showErrorAlert:@"Lỗi Máy Chủ" withMessage:@"Tải Data Thất Bại"];
                                                                       } else {
                                                                         NSString *tempZipPath =
                                                                             [documentDir
                                                                                 stringByAppendingPathComponent:
                                                                                     @"Resources.zip"];
                                                                         [data
                                                                             writeToFile:
                                                                                 tempZipPath
                                                                              atomically:
                                                                                  YES];
                                                                         BOOL success = [SSZipArchive
                                                                             unzipFileAtPath:
                                                                                 tempZipPath
                                                                               toDestination:
                                                                                   dataPathQuang];
                                                                         [fileManager
                                                                             removeItemAtPath:
                                                                                 tempZipPath
                                                                                        error:
                                                                                            nil];
                                                                         if (success) {
                                                                           [self showSuccessAlert:@"Mod Skin Thành Công!" withExit:YES]; 
                                                                         } else {
                                                                           [self showErrorAlert:@"Error" withMessage:@"Giải Nén Tệp Zip Thất Bại\nVui lòng Tạo Tệp Zip Như Hướng Dẫn"];
                                                                         }
                                                                       }
                                                                     }];
                                        }
                                      }
                                    }]];
    [[UIApplication sharedApplication].keyWindow.rootViewController
        presentViewController:dialogCtrl
                     animated:YES
                   completion:nil];
}

+ (void)showCreatingBackupAlert {
    alertCtrl = [UIAlertController alertControllerWithTitle:@"Creating" message:@"Đang tạo file backup..." preferredStyle:UIAlertControllerStyleAlert];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)showLoadingAlert {
    alertCtrl = [UIAlertController alertControllerWithTitle:@"Loading" message:@"Đang tải data mod skin\nVui lòng chờ trong giây lát..." preferredStyle:UIAlertControllerStyleAlert];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)showErrorAlert:(NSString *)title withMessage:(NSString *)message {
    alertCtrl = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleDefault handler:nil]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)showSuccessAlert:(NSString *)message withExit:(BOOL)exitApp {
    alertCtrl = [UIAlertController alertControllerWithTitle:@"Successfully" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (exitApp) {
            [self exitApp];
        }
    }]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)exitApp {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIAlertController *exitAlert = [UIAlertController alertControllerWithTitle:@"Thông báo" message:@"App sẽ đóng. Vui lòng vào lại để sử dụng mod." preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(0); // Thoát ứng dụng
        }];
        [exitAlert addAction:okAction];
        [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:exitAlert animated:YES completion:nil];
    });
}







+ (void)RemoveModSkin {
    NSString *dataPathQuang = [documentDir stringByAppendingPathComponent:@"/"];
    NSString *backupPathQuang = [documentDir stringByAppendingPathComponent:@"/Resources.backup"];

    if ([fileManager fileExistsAtPath:backupPathQuang]) {
        NSError *deleteErrorQuang;
        if ([fileManager removeItemAtPath:[dataPathQuang stringByAppendingPathComponent:@"/Resources"] error:&deleteErrorQuang]) {
            NSError *renameErrorQuang;
            if ([fileManager moveItemAtPath:backupPathQuang toPath:[dataPathQuang stringByAppendingPathComponent:@"/Resources"] error:&renameErrorQuang]) {
                [self showSuccessRestoreAlert];
            } else {
                [self showInvalidBackupErrorAlert];
            }
        } else {
            [self showDeleteErrorAlert];
        }
    } else {
        [self showNoBackupErrorAlert];
    }
}

+ (void)showSuccessRestoreAlert {
    alertCtrl = [UIAlertController alertControllerWithTitle:@"Successfully" message:@"Dữ liệu đã được khôi phục!" preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self exitApp2];
    }]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)showInvalidBackupErrorAlert {
    alertCtrl = [UIAlertController alertControllerWithTitle:@"Error" message:@"File backup không hợp lệ hoặc lỗi không xác định" preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleDefault handler:nil]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)showDeleteErrorAlert {
    alertCtrl = [UIAlertController alertControllerWithTitle:@"Error" message:@"Không thể khôi phục dữ liệu do thư mục / file không tồn tại" preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleDefault handler:nil]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)showNoBackupErrorAlert {
    alertCtrl = [UIAlertController alertControllerWithTitle:@"Error" message:@"Không có file backup hoặc hiện đã là data gốc" preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleDefault handler:nil]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

+ (void)exitApp2 {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        UIAlertController *exitAlert = [UIAlertController alertControllerWithTitle:@"Thông báo" message:@"App sẽ đóng. Vui lòng vào lại để hoàn tất xóa mod." preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            exit(0); // Thoát ứng dụng
        }];
        [exitAlert addAction:okAction];
        [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:exitAlert animated:YES completion:nil];
    });
}

@end
